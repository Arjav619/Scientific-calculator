# Scientific-Calculator-in-C
<h3>Output</h3>
<img src="https://github.com/akhtar02/Scientific-Calculator-in-C/blob/master/output.jpg">
